# Swap two numbers without using a third variable
a = 5
b = 10
print("Before swap:", a, b)
a, b = b, a
print("After swap:", a, b)