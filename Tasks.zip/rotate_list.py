# Rotate list by k positions
def rotate(lst, k):
    k %= len(lst)
    return lst[-k:] + lst[:-k]

print(rotate([1,2,3,4,5], 2))