# Function to reverse a string
def reverse_string(s):
    return s[::-1]

print(reverse_string("hello"))