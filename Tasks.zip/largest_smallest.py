# Find largest and smallest number in a list
lst = [10, 20, 4, 45, 99]
print("Largest:", max(lst))
print("Smallest:", min(lst))