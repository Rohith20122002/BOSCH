# Count vowels and consonants in a string
def count_vowels_consonants(s):
    vowels = "aeiouAEIOU"
    v = sum(1 for c in s if c in vowels)
    c = sum(1 for c in s if c.isalpha() and c not in vowels)
    return v, c

print(count_vowels_consonants("Hello World"))