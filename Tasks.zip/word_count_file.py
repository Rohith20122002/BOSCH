# Count words in text file
def count_words(filename):
    with open(filename, 'r') as f:
        text = f.read()
    return len(text.split())

# Example usage (ensure sample.txt exists)
# print(count_words("sample.txt"))