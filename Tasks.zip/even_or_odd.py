# Function to check if a number is even or odd
def even_or_odd(n):
    return "Even" if n % 2 == 0 else "Odd"

print(even_or_odd(7))
print(even_or_odd(10))