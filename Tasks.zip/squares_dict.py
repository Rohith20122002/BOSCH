# Dictionary with squares of numbers 1-10
d = {x: x**2 for x in range(1, 11)}
print(d)