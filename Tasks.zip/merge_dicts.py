# Merge two dictionaries
d1 = {"a":1,"b":2}
d2 = {"c":3,"d":4}
merged = {**d1, **d2}
print(merged)