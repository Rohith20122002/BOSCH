# Simple Calculator
def calc(a, b, op):
    if op == '+': return a+b
    if op == '-': return a-b
    if op == '*': return a*b
    if op == '/': return a/b if b != 0 else "Error"
    return "Invalid"

print(calc(10,5,'+'))
print(calc(10,5,'/'))