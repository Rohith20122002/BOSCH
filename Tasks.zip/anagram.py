# Check if two strings are anagrams
def is_anagram(s1, s2):
    return sorted(s1) == sorted(s2)

print(is_anagram("listen","silent"))
print(is_anagram("hello","world"))