# Function to sum values using **kwargs
def sum_kwargs(**kwargs):
    return sum(kwargs.values())

print(sum_kwargs(a=10, b=20, c=5))