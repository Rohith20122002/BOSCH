# Read command line args
import sys
print("Arguments passed:", sys.argv)