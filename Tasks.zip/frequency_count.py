# Count frequency of each element in a list
lst = [1,2,2,3,4,4,4,5]
freq = {}
for i in lst:
    freq[i] = freq.get(i, 0) + 1
print(freq)